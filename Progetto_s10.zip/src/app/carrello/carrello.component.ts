import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-carrello',
  templateUrl: './carrello.component.html',
  styleUrls: ['./carrello.component.scss']
})
export class CarrelloComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  submit(form : NgForm){
   console.log(form.value)
   form.reset();
 }

}
