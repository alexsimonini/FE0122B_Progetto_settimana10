import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../models/product'

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

   baseUrl = 'http://localhost:4201';


   //Per chiamare la lista prodotti: `${this.baseUrl}`
   //Per chiamare un prodotto in dettaglio: `  `

  constructor(private http: HttpClient) { }

  caricaProdotti() {
   return this.http.get<Product[]>(`${this.baseUrl}/products`);
}

caricaDettaglio(id:number) {
   return this.http.get(`${this.baseUrl}/products/${id}`);
}

}
