import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductsService } from '../service/products.service';
import { Product } from '../models/product';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

   prodottiInArrivo!: Product[];

   sub!: Subscription;


  constructor(private router: Router, private prodSrv: ProductsService) { }

  ngOnInit(): void{
   this.sub = this.prodSrv.caricaProdotti().subscribe((products) => {
      this.prodottiInArrivo = products;
      console.log(this.prodottiInArrivo)
   })
  }


  carrello() {
     this.router.navigate(['/carrello'])
  }
}
